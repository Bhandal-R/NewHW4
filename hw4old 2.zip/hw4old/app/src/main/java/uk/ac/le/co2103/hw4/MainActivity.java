package uk.ac.le.co2103.hw4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private ShoppingListViewModel shoppingListViewModel;

    public static final int REQUEST_CODE = 1;


    private Bitmap n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate()");

        setContentView(R.layout.activity_main);


        RecyclerView shoppinglist_delete_menu = findViewById(R.id.recyclerview);
        registerForContextMenu(shoppinglist_delete_menu);


        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final ShoppingListAdapter adapter = new ShoppingListAdapter();
        recyclerView.setAdapter(adapter);


        shoppingListViewModel = new ViewModelProvider(this).get(ShoppingListViewModel.class);
        shoppingListViewModel.getAllShoppingLists().observe(this, new Observer<List<ShoppingList>>() {
            @Override
            public void onChanged(List<ShoppingList> shoppingLists) {
                adapter.setShoppingList(shoppingLists);
            }
        });



        adapter.setOnShoppingListClickListener(new ShoppingListAdapter.onShoppingListClickListener() {
            @Override
            public void onShoppingListClick(ShoppingList shoppingList) {
                Intent intent = new Intent(MainActivity.this, ShoppingListActivity.class);
                intent.putExtra(ShoppingListActivity.EXTRA_REPLY_listID, shoppingList.getListId());
                startActivity(intent);
            }
        });

        adapter.setOnShoppingListLongClickListener(new ShoppingListAdapter.onShoppingListLongClickListener() {
            @Override
            public void onShoppingListLongClick(ShoppingList shoppingList) {

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Delete Shopping List")
                        .setMessage("Are you sure you want to delete the shopping list?")

                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                shoppingListViewModel.delete(shoppingList);
                                Toast.makeText(getApplicationContext(),"Deleted",Toast.LENGTH_SHORT).show();
                            }
                        })

                        .setNegativeButton(android.R.string.no, null)
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();


            }
        });




        final FloatingActionButton button = findViewById(R.id.fab);
        button.setOnClickListener(view -> {
            Log.d(TAG, "Floating action button clicked.");
            Toast.makeText(getApplicationContext(), "Add Item clicked", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, CreateListActivity.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    public byte[] fromBitmap(Bitmap bitmap){
        ByteArrayOutputStream s = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, s);
        return s.toByteArray();
    }





    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {
            String receivedImgUris = data.getStringExtra(CreateListActivity.EXTRA_REPLY_IMAGE);

            if(receivedImgUris != null) {
                String receivedImgUri = data.getStringExtra(CreateListActivity.EXTRA_REPLY_IMAGE);

                try {
                    n = MediaStore.Images.Media.getBitmap(getContentResolver(), Uri.parse(receivedImgUri));
                } catch (IOException e) {
                    n = null;
                }
            }
            if (n == null){
                ShoppingList shoppingList = new ShoppingList(data.getStringExtra(CreateListActivity.EXTRA_REPLY_NAME));
                
                shoppingListViewModel.insert(shoppingList);


            }
            else {
                ShoppingList shoppingList = new ShoppingList(data.getStringExtra(CreateListActivity.EXTRA_REPLY_NAME),fromBitmap(n));
                shoppingListViewModel.insert(shoppingList);

            }






//            Toast.makeText(getApplicationContext(),n.toString(),Toast.LENGTH_LONG).show();

//            shoppingListViewModel = new ViewModelProvider(this).get(ShoppingListViewModel.class);
//            if (shoppingListViewModel.uniqueName(data.getStringExtra(CreateListActivity.EXTRA_REPLY_NAME)) == 0) {
//                ShoppingListDatabase.getInstance(this).shoppingListDao().exists(CreateListActivity.EXTRA_REPLY_NAME)== 0

//            getImg = data.getByteArrayExtra(CreateListActivity.EXTRA_REPLY_IMAGE);


            }
//            else{
//                Toast.makeText(
//                        getApplicationContext(),
//                        "Name already exists!",
//                        Toast.LENGTH_LONG).show();

//            }
//        }
        else {
            Log.i(TAG, "Left Empty");
        }
    }






}