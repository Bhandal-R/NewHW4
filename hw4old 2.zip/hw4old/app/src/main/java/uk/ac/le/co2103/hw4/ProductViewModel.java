package uk.ac.le.co2103.hw4;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ProductViewModel extends AndroidViewModel {

        private ProductRepository repo;
        private LiveData<List<Product>> allProducts;


        public ProductViewModel(@NonNull Application application) {
            super(application);
            repo = new ProductRepository(application);
            allProducts = repo.getAllProductLists();
        }

        public void insert(Product product){
            repo.insert(product);
        }

        public void delete(Product product){
        repo.delete(product);
    }

        public void update(Product product){
        repo.update(product);
    }


        public LiveData<List<Product>> getProducts() {
            return allProducts;
        }

        public LiveData<List<Product>> getAllProductById(int id){
            LiveData<List<Product>> allProductsById = repo.getAllProductListsById(id);
        return  allProductsById; }


}


