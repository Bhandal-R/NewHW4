package uk.ac.le.co2103.hw4;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import static uk.ac.le.co2103.hw4.CreateListActivity.EXTRA_REPLY_IMAGE;
import static uk.ac.le.co2103.hw4.CreateListActivity.EXTRA_REPLY_NAME;

public class ShoppingListActivity extends AppCompatActivity {


    private static final String T = ShoppingListActivity.class.getSimpleName();
    ProductViewModel productViewModel;
    public static final int CODE = 1;
    public static final int edit = 11;
    private int intCheck;


    public static final String EXTRA_REPLY_listID = "uk.ac.le.co2103.hw4.id";
    public static final String EXTRA_REPLY_productID = "uk.ac.le.co2103.hw4.id";

    public static final String EXTRA_REPLY_updateNAME = "uk.ac.le.co2103.hw4.name";
    public static final String EXTRA_REPLY_updateQUANTITY = "uk.ac.le.co2103.hw4.quantity";
    public static final String EXTRA_REPLY_updateUNIT = "uk.ac.le.co2103.hw4.unit";

    private int productId;
    private int listId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        Intent intent = getIntent();
        listId = intent.getIntExtra(EXTRA_REPLY_listID,-1);

        if (listId == -1){
            Toast.makeText(ShoppingListActivity.this, "Error with shopping list ID",Toast.LENGTH_SHORT).show();
        }

        Log.d(T, "onCreate");


        RecyclerView recyclerView = findViewById(R.id.recyclerview_product);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final ProductAdapter adapter = new ProductAdapter();
        recyclerView.setAdapter(adapter);

        productViewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        productViewModel.getAllProductById(listId).observe(this, new Observer<List<Product>>() {
            @Override
            public void onChanged(List<Product> products) {
                adapter.setProducts(products);
            }
        });

//        Intent productIdIntent = new Intent();
//        productId = productIdIntent.getIntExtra(EXTRA_REPLY_productID, -1);
//
//        if (productId == -1){
//            Toast.makeText(getApplicationContext(),"Product ID error",Toast.LENGTH_SHORT).show();
//        }


        adapter.setOnProductClickListener(new ProductAdapter.productClickListener() {
            @Override
            public void onProductClick(Product product) {

                AlertDialog alertDialog = new AlertDialog.Builder(ShoppingListActivity.this).create();
                alertDialog.setTitle("Options");
                alertDialog.setMessage("Please choose an option");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Edit",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                                Intent productIntent = new Intent(ShoppingListActivity.this, UpdateProductActivity.class);

                            productIntent.putExtra(EXTRA_REPLY_updateNAME, product.getName());
                            productIntent.putExtra("name", product.getName());
                            productIntent.putExtra(EXTRA_REPLY_updateQUANTITY, String.valueOf(product.getQuantity()));
                            productIntent.putExtra("quantity", String.valueOf(product.getQuantity()));
                            productIntent.putExtra(EXTRA_REPLY_updateUNIT, product.getUnit());
                            productIntent.putExtra("unit", product.getUnit());
                            productIntent.putExtra(EXTRA_REPLY_listID, product.getListId());
                            productIntent.putExtra(EXTRA_REPLY_productID, product.getProductId());
                            startActivityForResult(productIntent, edit);
                            }
                        });

                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "Delete",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                productViewModel.delete(product);
                            }
                        });

                alertDialog.show();



            }
        });

        final FloatingActionButton button = findViewById(R.id.fabAddProduct);
        button.setOnClickListener(view -> {
            Log.d(T, "Add product button clicked.");
            Toast.makeText(getApplicationContext(), "Add product clicked", Toast.LENGTH_LONG).show();
            Intent intentProduct = new Intent(this, AddProductActivity.class);
            startActivityForResult(intentProduct, CODE);
        });


    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        int counter = 0;

        if (requestCode == CODE && resultCode == RESULT_OK)  {


            try {
                intCheck = Integer.parseInt(data.getStringExtra(AddProductActivity.EXTRA_REPLY_QUANTITY));
                counter+=1;

            } catch (NumberFormatException e) {
                counter=0;

            }

            if (counter == 1){

                Product product = new Product(data.getStringExtra(AddProductActivity.EXTRA_REPLY_NAME),Integer.parseInt(data.getStringExtra(AddProductActivity.EXTRA_REPLY_QUANTITY)),data.getStringExtra(AddProductActivity.EXTRA_REPLY_UNIT),listId);
                productViewModel.insert(product);
            }



            else {
                Toast.makeText(
                        getApplicationContext(),
                        "Error with adding product",
                        Toast.LENGTH_LONG).show();

            }



        }



        if (requestCode == edit && resultCode == RESULT_OK){
            Product p = new Product(1,data.getStringExtra(EXTRA_REPLY_updateNAME),Integer.parseInt(data.getStringExtra(EXTRA_REPLY_updateQUANTITY)),data.getStringExtra(EXTRA_REPLY_updateUNIT),listId);
            productViewModel.update(p);


//                Toast.makeText(
//                        getApplicationContext(),
//                        data.getStringExtra(EXTRA_REPLY_updateNAME),
//                        Toast.LENGTH_LONG).show();





        }


            else {
                Log.i(T,"Changes not made");
        }





    }
}