package uk.ac.le.co2103.hw4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class UpdateProductActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private static final String T = AddProductActivity.class.getSimpleName();
    public static final String EXTRA_REPLY_NAME = "uk.ac.le.co2103.hw4.name";
    public static final String EXTRA_REPLY_QUANTITY = "uk.ac.le.co2103.hw4.quantity";
    public static final String EXTRA_REPLY_UNIT = "uk.ac.le.co2103.hw4.unit";
    private EditText editTextName;
    private EditText editTextQuantity;
    private Spinner editTextUnit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);


        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.labels_unit, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);



        editTextName = findViewById(R.id.editTextName);

        editTextQuantity = findViewById(R.id.editTextQuantity);

        editTextUnit = findViewById(R.id.spinner);

        String kg = "Kg";
        String liter = "Liter";


        Intent intent = getIntent();

        editTextName.setText(intent.getExtras().getString("name"));
        editTextQuantity.setText(intent.getExtras().getString("quantity"));

        String spinSet =  intent.getExtras().getString("unit");



        if (spinSet.equals(kg)){
            editTextUnit.setSelection(1);

        }
        if (spinSet.equals(liter)){
            editTextUnit.setSelection(2);

        }




        Button plus = findViewById(R.id.plus);
        plus.setOnClickListener(view -> {
            int increment;
            increment = Integer.parseInt(editTextQuantity.getText().toString());
            increment +=1;

            editTextQuantity.setText(String.valueOf(increment));

        });
        Button minus = findViewById(R.id.minus);

        minus.setOnClickListener(view -> {
            int decrement;
            decrement = Integer.parseInt(editTextQuantity.getText().toString());
            decrement-=1;
            editTextQuantity.setText(String.valueOf(decrement));

            if (Integer.parseInt(editTextQuantity.getText().toString()) <= 0){
                editTextQuantity.setText("0");
                Toast.makeText(getApplicationContext(),"Quantity cannot be negative or 0",Toast.LENGTH_SHORT).show();



            }

        });


        final Button button = findViewById(R.id.button_Save);
        button.setOnClickListener(view -> {
            Intent extraReplyIntent = new Intent();

            if (TextUtils.isEmpty(editTextName.getText())) {
                Log.i(T, "Name field is empty");
                setResult(RESULT_CANCELED, extraReplyIntent);
            } else {
                String productName = editTextName.getText().toString();
                String productQuantity = editTextQuantity.getText().toString();
                String productUnit = editTextUnit.getSelectedItem().toString();
                extraReplyIntent.putExtra(EXTRA_REPLY_NAME, productName);
                extraReplyIntent.putExtra(EXTRA_REPLY_QUANTITY, productQuantity);
                extraReplyIntent.putExtra(EXTRA_REPLY_UNIT, productUnit);
                setResult(RESULT_OK, extraReplyIntent);;
            }
            finish();
        });


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}