package uk.ac.le.co2103.hw4;

import android.graphics.Bitmap;
import android.media.Image;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.util.ArrayList;
import java.util.List;

@Entity(tableName = "shoppingList_table")
public class ShoppingList {

    @PrimaryKey(autoGenerate = true)
    public int listId;

    @NonNull
    public String name;

    @ColumnInfo(typeAffinity = ColumnInfo.BLOB)
    public byte[] image;

    public ShoppingList(@NonNull String name, byte[] image) {
        this.name = name;
        this.image = image;
    }

    @Ignore
    public ShoppingList(@NonNull String name) {
        this.name = name;
    }



    public int getListId() {
        return listId;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public byte[] getImage() {
        return image;
    }

    public void setListId(int listId) {
        this.listId = listId;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
