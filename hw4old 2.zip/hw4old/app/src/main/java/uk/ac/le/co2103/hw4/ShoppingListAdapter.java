package uk.ac.le.co2103.hw4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingListAdapter extends RecyclerView.Adapter<ShoppingListAdapter.ShoppingListHolder> {
    private List<ShoppingList> shoppingList = new ArrayList<>();
    private onShoppingListClickListener listener;
    private onShoppingListLongClickListener listenerLong;



    @NonNull
    @Override
    public ShoppingListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_main, parent, false);


        return new ShoppingListHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ShoppingListHolder holder, int position) {

        ShoppingList currentSL = shoppingList.get(position);


        if (currentSL.getImage() == null){

            holder.txtViewName.setText(currentSL.getName());

        }

        else {
            String encodeImg = Base64.encodeToString(currentSL.getImage(), Base64.DEFAULT);
            holder.txtViewName.setText(currentSL.getName());
            byte[] imageByte = Base64.decode(encodeImg, Base64.DEFAULT);

            Bitmap b = BitmapFactory.decodeByteArray(imageByte, 0, imageByte.length);

            holder.txtViewImage.setImageBitmap(b);

        }




    }




    @Override
    public int getItemCount() {
        return shoppingList.size();
    }

    public void setShoppingList(List<ShoppingList> shoppingList){
        this.shoppingList = shoppingList;
        notifyDataSetChanged();
    }

    public ShoppingList getShoppingPos (int position){
        return shoppingList.get(position);
    }

    class ShoppingListHolder extends RecyclerView.ViewHolder{
        private TextView txtViewName;
        private ImageView txtViewImage;

        public ShoppingListHolder(@NonNull View shoppingListView) {
            super(shoppingListView);
            txtViewName = shoppingListView.findViewById(R.id.txt_name);
            txtViewImage = shoppingListView.findViewById(R.id.image_upload);

            shoppingListView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    int pos = getAdapterPosition();
                    if(listenerLong !=null && pos != RecyclerView.NO_POSITION){
                        listenerLong.onShoppingListLongClick(shoppingList.get(pos));
                    }
                    return false;
                }
            });




            shoppingListView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (listener!= null && position != RecyclerView.NO_POSITION) {
                        listener.onShoppingListClick(shoppingList.get(position));
                    }
                }
            });
        }
    }

    public interface onShoppingListLongClickListener{
        void onShoppingListLongClick(ShoppingList shoppingList);
    }

    public void setOnShoppingListLongClickListener(onShoppingListLongClickListener listenerLong){
        this.listenerLong = listenerLong;
    }



    public interface onShoppingListClickListener{
        void onShoppingListClick(ShoppingList shoppingList);
    }

    public void setOnShoppingListClickListener(onShoppingListClickListener listener){
        this.listener = listener;
    }

}
