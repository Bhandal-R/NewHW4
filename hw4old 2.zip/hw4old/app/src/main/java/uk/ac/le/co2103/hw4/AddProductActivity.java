package uk.ac.le.co2103.hw4;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddProductActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String T = AddProductActivity.class.getSimpleName();

    public static final String EXTRA_REPLY_NAME = "uk.ac.le.co2103.hw4.name";
    public static final String EXTRA_REPLY_QUANTITY = "uk.ac.le.co2103.hw4.quantity";
    public static final String EXTRA_REPLY_UNIT = "uk.ac.le.co2103.hw4.unit";
    private EditText editTextName;
    private EditText editTextQuantity;
    private Spinner editTextUnit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(T, "onCreate");

        setContentView(R.layout.activity_add_product);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.labels_unit, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);





        editTextName = findViewById(R.id.editTextName);

        editTextQuantity = findViewById(R.id.editTextQuantity);

        editTextUnit = findViewById(R.id.spinner);

        final Button button = findViewById(R.id.button_Save);
        button.setOnClickListener(view -> {
            Intent extraReplyIntent = new Intent();
            if (TextUtils.isEmpty(editTextName.getText())) {
                Log.i(T, "Name is empty");
                setResult(RESULT_CANCELED, extraReplyIntent);
            } else {
                Log.i(T, "Adding Product");
                String productName = editTextName.getText().toString();
                String productQuantity = editTextQuantity.getText().toString();
                String productUnit = editTextUnit.getSelectedItem().toString();
                extraReplyIntent.putExtra(EXTRA_REPLY_NAME, productName);
                extraReplyIntent.putExtra(EXTRA_REPLY_QUANTITY, productQuantity);
                extraReplyIntent.putExtra(EXTRA_REPLY_UNIT, productUnit);
                setResult(RESULT_OK, extraReplyIntent);;
            }
            finish();
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
