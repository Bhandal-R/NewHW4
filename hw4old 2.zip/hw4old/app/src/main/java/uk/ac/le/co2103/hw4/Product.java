package uk.ac.le.co2103.hw4;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = ShoppingList.class, parentColumns = "listId", childColumns = "listId", onDelete = ForeignKey.CASCADE))
public class Product {

    @PrimaryKey(autoGenerate = true)
    public int productId;

    @NonNull
    public String name;

    @NonNull
    public int quantity;

    @NonNull
    public String unit;

    @NonNull
    public String getName() {
        return name;
    }

    private int listId;


    public Product( @NonNull String name, @NonNull int quantity, String unit, int listId) {
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.listId = listId;
    }

    @Ignore
    public Product(int productId, @NonNull String name, @NonNull int quantity, String unit, int listId) {
        this.productId = productId;
        this.name = name;
        this.quantity = quantity;
        this.unit = unit;
        this.listId = listId;
    }


    public void setName(@NonNull String name) {
        this.name = name;
    }

    @NonNull
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(@NonNull int quantity) {
        this.quantity = quantity;
    }

    @NonNull
    public String getUnit() {
        return unit;
    }

    public void setUnit(@NonNull String unit) {
        this.unit = unit;
    }


    public int getListId() {
        return listId;
    }

    public void setListId(int listId) {
        this.listId = listId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}

