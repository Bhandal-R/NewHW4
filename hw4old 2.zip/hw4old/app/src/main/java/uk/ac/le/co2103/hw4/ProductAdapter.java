package uk.ac.le.co2103.hw4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductHolder> {

    private List<Product> products = new ArrayList<>();

    private productClickListener listener;


    class ProductHolder extends RecyclerView.ViewHolder {



        private TextView txtViewName;
        private TextView txtViewQuantity;
        private TextView txtViewUnit;


        public ProductHolder(View itemView) {
            super(itemView);
            txtViewName = itemView.findViewById(R.id.txt_product_name);
            txtViewQuantity = itemView.findViewById(R.id.txt_product_quantity);
            txtViewUnit = itemView.findViewById(R.id.txt_product_unit);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    if (listener!= null && position != RecyclerView.NO_POSITION) {
                        listener.onProductClick(products.get(position));
                    }


                }

            });





        }
    }


    @NonNull
    @Override
    public ProductAdapter.ProductHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recyclerview_productlist, parent, false);
        return new ProductHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ProductHolder holder, int position) {
        Product currentProduct = products.get(position);
        holder.txtViewName.setText(currentProduct.getName());
        holder.txtViewQuantity.setText(Integer.toString(currentProduct.getQuantity()));
        holder.txtViewUnit.setText(currentProduct.getUnit());
    }

    public void setProducts(List<Product> products){
        this.products = products;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public interface productClickListener{
        void onProductClick(Product product);
    }

    public void setOnProductClickListener(productClickListener listener){
        this.listener = listener;
    }

}