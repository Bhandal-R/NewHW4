package uk.ac.le.co2103.hw4;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ProductRepository {

    private ProductDao productDao;
    private LiveData<List<Product>> allProductLists;
    private LiveData<List<Product>> allProductListsById;

    public ProductRepository(Application application){
        ShoppingListDatabase db = ShoppingListDatabase.getInstance(application);
        productDao = db.productDao();
        allProductLists = productDao.getAllProducts();
    }

    public void insert(Product product){
        new ProductRepository.InsertProduct(productDao).execute(product);

    }
    public void update(Product product){
        new ProductRepository.UpdateProduct(productDao).execute(product);

    }
    public void delete(Product product){
        new ProductRepository.deleteProduct(productDao).execute(product);

    }
    public void deleteAllShoppingList(){
        new ProductRepository.deleteAllProduct(productDao).execute();

    }

    public LiveData<List<Product>> getAllProductLists(){
        return  allProductLists;
    }


    public LiveData<List<Product>> getAllProductListsById(int id){
        LiveData<List<Product>> allProductsById = productDao.getAllProducts(id);
        return allProductsById;
    }


    private static class InsertProduct extends AsyncTask<Product,Void,Void> {
        private ProductDao productDao;

        private InsertProduct(ProductDao productDao){
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.insert(products[0]);
            return null;
        }
    }

    private static class UpdateProduct extends AsyncTask<Product,Void,Void> {
        private ProductDao productDao;

        private UpdateProduct(ProductDao productDao){
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.update(products[0]);
            return null;
        }
    }

    private static class deleteProduct extends AsyncTask<Product,Void,Void> {
        private ProductDao productDao;

        private deleteProduct(ProductDao productDao){
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Product... products) {
            productDao.delete(products[0]);
            return null;
        }
    }


    private static class deleteAllProduct extends AsyncTask<Void,Void,Void> {
        private ProductDao productDao;

        private deleteAllProduct(ProductDao productDao){
            this.productDao = productDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            productDao.deleteAllProducts();
            return null;
        }
    }

}

