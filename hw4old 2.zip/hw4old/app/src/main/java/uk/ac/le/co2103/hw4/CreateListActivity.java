package uk.ac.le.co2103.hw4;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class CreateListActivity extends AppCompatActivity {


    private static final String T = CreateListActivity.class.getSimpleName();
    public static final String EXTRA_REPLY_NAME = "uk.ac.le.co2103.hw4.name";
    public static final String EXTRA_REPLY_IMAGE = "uk.ac.le.co2103.hw4.image";
    private EditText editTxtShoppingList;
    private ImageView editTxtShoppingList2;

    private Uri ImageUri;

    private Bitmap bitmapImg;
    private byte[] inputData;


    public static final int REQUEST_CODE = 1;



    public byte[] fromBitmap(Bitmap bitmap){
        ByteArrayOutputStream s = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, s);
        return s.toByteArray();
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK){
            ImageUri = data.getData();
            try {
                bitmapImg = MediaStore.Images.Media.getBitmap(getContentResolver(),ImageUri);
                editTxtShoppingList2.setImageBitmap(bitmapImg);

                inputData = fromBitmap(bitmapImg);

            }catch (IOException e){
                e.printStackTrace();
            }
        }

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(T, "onCreate");

        setContentView(R.layout.activity_add_shoppinglist);

        editTxtShoppingList = findViewById(R.id.edit_txt_name);

        editTxtShoppingList2 = findViewById(R.id.add_image);

        editTxtShoppingList2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), REQUEST_CODE);

            }
        });



        final Button button = findViewById(R.id.button_Save);
        button.setOnClickListener(view -> {
            Intent extraReplyIntent = new Intent();
            if (TextUtils.isEmpty(editTxtShoppingList.getText())) {
                Log.i(T, "Name is empty");
                setResult(RESULT_CANCELED, extraReplyIntent);
            }
            if (ImageUri == (null)){
                String shoppingList1 = editTxtShoppingList.getText().toString();
                extraReplyIntent.putExtra(EXTRA_REPLY_NAME, shoppingList1);

                setResult(RESULT_OK, extraReplyIntent);;
            }




            else {
                Log.i(T, "Adding shopping list");
                String shoppingList1 = editTxtShoppingList.getText().toString();
                String encodeImg = Base64.encodeToString(inputData, Base64.DEFAULT);
                extraReplyIntent.putExtra(EXTRA_REPLY_NAME, shoppingList1);

                extraReplyIntent.putExtra(EXTRA_REPLY_IMAGE, ImageUri.toString());

                setResult(RESULT_OK, extraReplyIntent);;
            }
            finish();
        });
    }

}
