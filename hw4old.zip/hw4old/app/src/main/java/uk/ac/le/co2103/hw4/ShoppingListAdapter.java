package uk.ac.le.co2103.hw4;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ShoppingListAdapter extends RecyclerView.Adapter<ShoppingListAdapter.ShoppingListHolder> {
    private List<ShoppingList> shoppingList = new ArrayList<>();

    @NonNull
    @Override
    public ShoppingListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.shoppinglist_item, parent, false);
        return new ShoppingListHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ShoppingListHolder holder, int position) {
        ShoppingList currentSL = shoppingList.get(position);
        holder.txtViewName.setText(currentSL.getName());
        holder.txtViewImage.setText(currentSL.getImage());
    }

    @Override
    public int getItemCount() {
        return shoppingList.size();
    }

    public void setShoppingList(List<ShoppingList> shoppingList){
        this.shoppingList = shoppingList;
        notifyDataSetChanged();
    }

    class ShoppingListHolder extends RecyclerView.ViewHolder{
        private TextView txtViewName;
        private TextView txtViewImage;

        public ShoppingListHolder(@NonNull View itemView) {
            super(itemView);
            txtViewName = itemView.findViewById(R.id.txt_name);
            txtViewImage = itemView.findViewById(R.id.txt_image);
        }
    }

}
