package uk.ac.le.co2103.hw4;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

@Database(entities = {ShoppingList.class}, version = 1, exportSchema = false)
public abstract class ShoppingListDatabase extends RoomDatabase {


    private  static ShoppingListDatabase instance;

    public abstract ShoppingListDao shoppingListDao();



    static ShoppingListDatabase getInstance(final Context context) {
        if (instance == null) {
            synchronized (ShoppingListDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                            ShoppingListDatabase.class, "shoppingListDatabase")
                            .fallbackToDestructiveMigration()
                            .addCallback(RoomDatabaseCallback)
                            .build();
                }
            }
        }
        return instance;
    }

    private static RoomDatabase.Callback RoomDatabaseCallback = new RoomDatabase.Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            new ShowShoppingLists(instance).execute();

//                ShoppingListDao dao = instance.shoppingListDao();

            }
        };


    private static class ShowShoppingLists extends AsyncTask<Void, Void, Void> {
        private ShoppingListDao shoppingListDao;

        private ShowShoppingLists(ShoppingListDatabase db){
            shoppingListDao = instance.shoppingListDao();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            shoppingListDao.insert(new ShoppingList("Test","T"));
            shoppingListDao.insert(new ShoppingList("Test","T"));
            shoppingListDao.insert(new ShoppingList("Test","T"));

            return null;
        }
    }



}

