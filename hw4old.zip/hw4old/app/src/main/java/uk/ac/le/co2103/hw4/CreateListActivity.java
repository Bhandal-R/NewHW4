package uk.ac.le.co2103.hw4;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class CreateListActivity extends AppCompatActivity {


    private static final String T = CreateListActivity.class.getSimpleName();
    public static final String EXTRA_REPLY_NAME = "uk.ac.le.co2103.hw4.name";
    public static final String EXTRA_REPLY_IMAGE = "uk.ac.le.co2103.hw4.image";
    private EditText editTxtShoppingList;
    private EditText editTxtShoppingList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(T, "onCreate");

        setContentView(R.layout.activity_add_shoppinglist);

        editTxtShoppingList = findViewById(R.id.edit_txt_name);

        editTxtShoppingList2 = findViewById(R.id.edit_txt_image);

        final Button button = findViewById(R.id.button_Save);
        button.setOnClickListener(view -> {
            Intent extraReplyIntent = new Intent();
            if (TextUtils.isEmpty(editTxtShoppingList.getText())) {
                Log.i(T, "Name field is empty");
                setResult(RESULT_CANCELED, extraReplyIntent);
            } else {
                Log.i(T, "Adding shopping list");
                String shoppingList1 = editTxtShoppingList.getText().toString();
                String shoppingList2 = editTxtShoppingList2.getText().toString();
                extraReplyIntent.putExtra(EXTRA_REPLY_NAME, shoppingList1);
                extraReplyIntent.putExtra(EXTRA_REPLY_IMAGE, shoppingList2);
                setResult(RESULT_OK, extraReplyIntent);;
            }
            finish();
        });
    }

}
