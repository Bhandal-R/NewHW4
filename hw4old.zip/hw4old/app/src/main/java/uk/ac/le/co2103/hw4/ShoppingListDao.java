package uk.ac.le.co2103.hw4;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ShoppingListDao {

    @Insert
    void insert(ShoppingList shoppingList);
    @Update
    void update(ShoppingList shoppingList);
    @Delete
    void delete(ShoppingList shoppingList);


    @Query("DELETE FROM shoppingList_table")
    void deleteAllShoppingLists();

    @Query("SELECT * FROM shoppingList_table ORDER BY name ASC")
    LiveData<List<ShoppingList>> getAllShoppingList();




}
