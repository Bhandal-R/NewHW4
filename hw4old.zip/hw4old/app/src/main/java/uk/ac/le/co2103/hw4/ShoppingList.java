package uk.ac.le.co2103.hw4;

import android.media.Image;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "shoppingList_table")
public class ShoppingList {

    @PrimaryKey(autoGenerate = true)
    public int listId;

    @NonNull
    public String name;

    public String image;

    public ShoppingList(@NonNull String name, String image) {
        this.name = name;
        this.image = image;
    }



    public int getListId() {
        return listId;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }

    public void setListId(int listId) {
        this.listId = listId;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
