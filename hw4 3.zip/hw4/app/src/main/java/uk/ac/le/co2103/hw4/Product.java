package uk.ac.le.co2103.hw4;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "product_table")
public class Product {

    @PrimaryKey
    @NonNull
    public String name;
    @NonNull
    public int quantity;

    @NonNull
    public String getName() {
        return name;
    }


    public Product(@NonNull String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getUnit() {
        return unit;
    }

    public void setUnit(int unit) {
        this.unit = unit;
    }

    @NonNull
    public int unit;


}
