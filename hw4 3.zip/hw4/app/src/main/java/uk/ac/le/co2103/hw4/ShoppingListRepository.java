package uk.ac.le.co2103.hw4;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.room.Update;

import java.util.List;

public class ShoppingListRepository {
    private ShoppingListDao shoppingListDao;
    private LiveData<List<ShoppingList>> allShoppingLists;

    public ShoppingListRepository(Application application){
        ShoppingListDatabase db = ShoppingListDatabase.getInstance(application);
        shoppingListDao = db.shoppingListDao();
        allShoppingLists = shoppingListDao.getAllShoppingList();
    }

    public void insert(ShoppingList shoppingList){
        new InsertShoppingList(shoppingListDao).execute(shoppingList);

    }
    public void update(ShoppingList shoppingList){
        new UpdateShoppingList(shoppingListDao).execute(shoppingList);

    }
    public void delete(ShoppingList shoppingList){
        new DeleteShoppingList(shoppingListDao).execute(shoppingList);

    }
    public void deleteAllShoppingList(){
        new deleteAllShoppingList(shoppingListDao).execute();

    }

    public LiveData<List<ShoppingList>> getAllShoppingLists(){
        return  allShoppingLists;
    }



    private static class InsertShoppingList extends AsyncTask<ShoppingList,Void,Void>{
        private ShoppingListDao shoppingListDao;

        private InsertShoppingList(ShoppingListDao shoppingListDao){
            this.shoppingListDao = shoppingListDao;
        }

        @Override
        protected Void doInBackground(ShoppingList... shoppingLists) {
            shoppingListDao.insert(shoppingLists[0]);
            return null;
        }
    }

    private static class UpdateShoppingList extends AsyncTask<ShoppingList,Void,Void>{
        private ShoppingListDao shoppingListDao;

        private UpdateShoppingList(ShoppingListDao shoppingListDao){
            this.shoppingListDao = shoppingListDao;
        }

        @Override
        protected Void doInBackground(ShoppingList... shoppingLists) {
            shoppingListDao.update(shoppingLists[0]);
            return null;
        }
    }

    private static class DeleteShoppingList extends AsyncTask<ShoppingList,Void,Void>{
        private ShoppingListDao shoppingListDao;

        private DeleteShoppingList(ShoppingListDao shoppingListDao){
            this.shoppingListDao = shoppingListDao;
        }

        @Override
        protected Void doInBackground(ShoppingList... shoppingLists) {
            shoppingListDao.delete(shoppingLists[0]);
            return null;
        }
    }

    private static class deleteAllShoppingList extends AsyncTask<Void,Void,Void>{
        private ShoppingListDao shoppingListDao;

        private deleteAllShoppingList(ShoppingListDao shoppingListDao){
            this.shoppingListDao = shoppingListDao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            shoppingListDao.deleteAllShoppingLists();
            return null;
        }
    }


}
